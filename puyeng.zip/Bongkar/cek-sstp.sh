#!/bin/bash

accel-cmd show sessions
echo ""